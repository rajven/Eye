UPDATE `config_options` SET `default_value` = '1', `max_value` = '10' WHERE `config_options`.`id` = 55;
UPDATE `config` SET `value` = '1' WHERE `config`.`option_id` = 55;
