ALTER TABLE `devices` ADD `netflow_save` BOOLEAN NOT NULL DEFAULT FALSE AFTER `discovery`;
