REPLACE INTO `version` (`version`) VALUES ('2.7.0');
