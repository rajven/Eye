ALTER TABLE `User_list` ADD `permanent` BOOLEAN NOT NULL DEFAULT FALSE AFTER `month_quota`;
