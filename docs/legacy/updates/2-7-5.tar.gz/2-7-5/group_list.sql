ALTER TABLE `Group_list` ADD `instance_id` INT NOT NULL DEFAULT '1' AFTER `id`;
