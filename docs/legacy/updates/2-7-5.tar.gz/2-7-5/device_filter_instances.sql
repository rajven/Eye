CREATE TABLE `device_filter_instances` (`id` INT NOT NULL AUTO_INCREMENT , `instance_id` INT NULL DEFAULT NULL , `device_id` INT NULL DEFAULT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
