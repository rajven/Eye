ALTER TABLE `User_auth` ADD `dhcp_option_set` VARCHAR(50) NULL DEFAULT NULL AFTER `dhcp_action`;
