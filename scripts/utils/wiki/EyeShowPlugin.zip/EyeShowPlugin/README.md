# EyeShowPlugin

EyeShowPlugin — плагин для Foswiki, отображающий информацию об авторизации,
пользователе и сетевых параметрах устройства по IP-адресу через внешний Eye API.

Плагин поддерживает конфигурацию **по web’ам** и может вызываться как напрямую
через макрос `%SHOWSTAT%`, так и через AJAX (RenderPlugin).

---

## Features

- Получение данных по IP через Eye API
- Поддержка нескольких web’ов с разными API-настройками
- Работа через `%SHOWSTAT%` или REST (AJAX)
- Генерация HTML-вывода, совместимого с Foswiki markup
- Без хранения состояния между запросами (thread-safe)

---

## Requirements

- Foswiki >= 1.1
- Perl modules:
  - `LWP::UserAgent`
  - `JSON`
  - `URI::Escape`
  - `HTTP::Request`

---

## Installation

### Manual installation

1. Скопировать плагин в каталог Foswiki:

```bash
cp -r EyeShowPlugin $FOSWIKI_ROOT/
```
2. Перейти в веб-интерфейс Configure:

Configure → Extensions

Убедиться, что EyeShowPlugin включён

3. Настроить параметры плагина (см. ниже)

Configuration

Конфигурация выполняется через Configure и хранится в LocalSite.cfg.

Плагин использует конфигурацию, привязанную к web’у, из которого был вызван макрос.

Пример конфигурации (LocalSite.cfg)
$Foswiki::cfg{Plugins}{EyeShowPlugin}{Enabled} = 1;

$Foswiki::cfg{Plugins}{EyeShowPlugin}{Configs} = '{
  "EXAMPLE": {
    "api_login": "wiki",
    "api_key": "changeme",
    "api_endpoint": "https://eye.example.com/api.php"
  }
}';


Ключ верхнего уровня должен точно совпадать с именем web’а (%BASEWEB%).

Usage
Simple macro usage
%SHOWSTAT{ host="192.0.2.10" }%

Допустимые параметры:

host — IP-адрес (обязателен)

ip — алиас для host

_DEFAULT — IP без имени параметра

AJAX usage (recommended)
```
<div id="container-showstat"></div>
<script type="text/javascript">
$(function() {
  $("#container-showstat").load(
    "%SCRIPTURLPATH{"rest"}%/RenderPlugin/tag",
    {
      name: 'SHOWSTAT',
      host: '%FORMFIELD{"DeviceIP" topic="%BASETOPIC%"}%',
      topic: '%BASEWEB%.%BASETOPIC%',
      web: '%BASEWEB%',
      render: true
    }
  );
});
</script>
```

## Notes

Плагин не хранит состояние между запросами и безопасен для
использования в нескольких web’ах одновременно.

Конфигурация выбирается динамически на основе $theWeb.

Рекомендуется использовать AJAX-вызов для снижения времени рендеринга страницы.

## Troubleshooting

"No config for web"

Убедитесь, что:

имя web’а указано в конфигурации, регистр букв совпадает, web существует

# Author

DmitrievRoman <mailto:rnd@rajven.ru>
