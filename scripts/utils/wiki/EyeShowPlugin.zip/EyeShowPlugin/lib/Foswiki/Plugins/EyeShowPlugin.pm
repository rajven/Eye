package Foswiki::Plugins::EyeShowPlugin;

use strict;
use warnings;
use utf8;
use LWP::UserAgent;
use JSON qw(decode_json encode_json);
use URI::Escape;
use HTTP::Request;
use vars qw($VERSION $RELEASE $pluginName);
use Foswiki::Func ();
use Foswiki::Plugins ();

#    use Data::Dumper;
#    Foswiki::Func::writeWarning("GET: ".Dumper($data));

$VERSION = '1.0';
$RELEASE = '1.0';

$pluginName = 'EyeShowPlugin';

sub initPlugin {
    my ($topic, $web) = @_;

    if ($Foswiki::Plugins::VERSION < 1.026) {
        Foswiki::Func::writeWarning("Version mismatch between $pluginName and Plugins.pm");
        return 0;
    }

    Foswiki::Func::registerTagHandler('SHOWSTAT',     \&_EyeAuthShow);
    Foswiki::Func::registerTagHandler('AUTHSHOW',     \&_EyeAuthShow);
    Foswiki::Func::registerTagHandler('SELECTVENDOR', \&_selectVendorApi);
    Foswiki::Func::registerTagHandler('SHOWSUBNET',   \&_showSubnetApi);
    Foswiki::Func::registerTagHandler('SHOWSUBNETIPS',\&_showUserListApi);

    return 1;
}

sub StrToIp {
return unpack('N',pack('C4',split(/\./,$_[0])));
}

sub IpToStr {
my $nIP = shift;
my $res = (($nIP>>24) & 255) .".". (($nIP>>16) & 255) .".". (($nIP>>8) & 255) .".". ($nIP & 255);
return $res;
}

sub api_call {
    my ($ua, $method, $url) = @_;
    my $req = HTTP::Request->new($method => $url);
    my $res = $ua->request($req);
    my $result;
    if (!$res->is_success) {
        $result->{error} = $res->status_line;
        return $result;
        }
    eval {
    $result->{data} = decode_json($res->decoded_content);
    };
    $result->{error} = "JSON parse error: $@" if $@;
    return $result;
}

sub _getApiData {
    my ($cfg, $params) = @_;

    my $ua = LWP::UserAgent->new(timeout => 30, agent => 'EyeWikiSync/1.0');

    my $base_url = $cfg->{api_endpoint};
    $base_url .= '?api_login=' . uri_escape($cfg->{api_login});
    $base_url .= '&api_key=' . uri_escape($cfg->{api_key});

    my $url = $base_url . '&' . $params;

    my $res = api_call($ua, 'GET', $url);
    if (!$res || $res->{error}) {
        return "API error: ". $res->{error};
    }
    return $res->{data};
}


sub _EyeAuthShow {
    my ($session, $params, $theTopic, $theWeb) = @_;

    my $cfg;
    foreach my $row (@{ $Foswiki::cfg{Plugins}{EyeShowPlugin}{Configs} }) {
        next if ($row->{web} ne $theWeb);
        $cfg = $row;
        last;
    }

    return "EyeShowPlugin: no config for web '$theWeb'" unless $cfg;

    # Поддерживаем разные варианты передачи адреса
    my $ip = $params->{host}  || $params->{ip} || $params->{_DEFAULT};

    return "Error: IP required" unless ($ip);

    my $auth_data = _getApiData($cfg, "get=user_auth&ip=" . uri_escape($ip));
    if (!$auth_data) {
        return "Запись не найдена для IP $ip\n";
    }

    # === Получаем доп. данные ===
    my ($user_data, $device_data, $nagios_url, $stat_url, $filter_name, $queue_name) = ({}, {}, '', '', '', '');

    # Пользователь
    my $uid = $auth_data->{user_id};
    if ($uid) {
        $user_data =  _getApiData($cfg, 'get=user&id='.$uid);
        if (!$user_data) {
            return "Запись польлзователя не найдена для IP $ip и user_id: $auth_data->{user_id}\n";
            }
        } else {
            return "Запись польлзователя не существует для IP $ip!\n";
	}

    # search device
    my $dev_filter = encode_json({ user_id => $uid });
    $device_data =  _getApiData($cfg, 'get=table_record&table=devices&filter='.$dev_filter);

    # URLs из config
    # Обработка специальных URL-опций
    for my $opt ([57, 'nagios_url'], [62, 'stat_url']) {
        my ($option_id, $option_name) = @$opt;
        # Формируем фильтр для API
        my $option_filter = encode_json({ option_id => $option_id });
        my $api_request = "get=table_record&table=config&filter=" . uri_escape($option_filter);
        # Выполняем API-запрос
        my $config_record =  _getApiData($cfg, $api_request);
        # Проверяем успешность ответа
        next if (!$config_record);
        # Получаем значение опции
        my $opt_value = $config_record->{value} // '';
        next if ($opt_value eq '');
        # Формируем конкретные URL в зависимости от типа опции
        if ($option_id == 57) {  # nagios_url
            my $host_param = $auth_data->{dns_name} || $auth_data->{ip} || 'unknown';
            $nagios_url = "$opt_value/cgi-bin/status.cgi?navbarsearch=1&host=" . uri_escape($host_param);
            }
        elsif ($option_id == 62) {  # stat_url
            if (!$device_data || !$device_data->{id}) {
                $stat_url = "$opt_value/admin/users/editauth.php?id=" . uri_escape($auth_data->{id} // '');
            } else {
                $stat_url = "$opt_value/admin/devices/editdevice.php?id=" . uri_escape($device_data->{id} // '');
            }
        }
    }

    # Имена фильтра и шейпера
    if (my $fid = $auth_data->{filter_group_id}) {
        my $filter =  _getApiData($cfg, "get=table_record&table=group_list&id=$fid");
        if ($filter) {
            $filter_name = $filter->{group_name};
            }
        }
    if (my $qid = $auth_data->{queue_id}) {
        my $queue =  _getApiData($cfg, "get=table_record&table=queue_list&id=$qid");
        if ($queue) {
            $queue_name = $queue->{queue_name};
            }
        }

    # === Формируем HTML ===
    my $login = $user_data->{login} || $auth_data->{description} || 'N/A';
    my $status = '<div style="float: right; width: 200px;">%BLUE%STAT:%ENDCOLOR%<br>';
    $status .= "id: $auth_data->{id}<br>";

    # Login
    if ($login && $login ne 'N/A') {
        $status .= $stat_url
        ? "Login: <a href=\"$stat_url\">$login</a><br>"
        : "Login: $login<br>";
        }

    # Enabled status
    $status .= $auth_data->{enabled} ? "Включен: Да<br>" : "Включен: Нет<br>";

    # Nagios
    if (defined $auth_data->{nagios} && $auth_data->{nagios}) {
        $status .= $nagios_url
        ? "Nagios: <a href=\"$nagios_url\">Да</a><br>"
        : "Nagios: Да<br>";
        }

    # DHCP hostname
    if ($auth_data->{dhcp_hostname} && $auth_data->{dhcp_hostname} ne '') {
        $status .= "Dhcp hostname: $auth_data->{dhcp_hostname}<br>";
        }

    # Filter
    my $filter_display = $filter_name || $auth_data->{filter_group_id} || '';
    if ($filter_display ne '') {
        $status .= "Фильтр: $filter_display<br>";
        }

    # Queue
    my $queue_display = $queue_name || $auth_data->{queue_id} || '';
    if ($queue_display ne '') {
        $status .= "Шейпер: $queue_display<br>";
        }

    # Description
    if ($auth_data->{description} && $auth_data->{description} ne '') {
        $status .= "Комментарий: $auth_data->{description}<br>";
        }

    # Last found
    if ($auth_data->{last_found} && $auth_data->{last_found} ne '') {
        $status .= "last found: $auth_data->{last_found}<br>";
        }

    $status .= '</div><div style="clear: left;"><p></p></div>';

    return $status;
}

sub _selectVendorApi {
    my ($session, $params, $theTopic, $theWeb) = @_;
    my $cfg;
    foreach my $row (@{ $Foswiki::cfg{Plugins}{EyeShowPlugin}{Configs} }) {
        next if ($row->{web} ne $theWeb);
        $cfg = $row;
        last;
    }

    return "EyeShowPlugin: no config for web '$theWeb'" unless $cfg;

    my $data = _getApiData($cfg, "get=table_list&table=vendors");
    return "" unless $data;

    my $out ='';
    foreach my $r (@{$data}) {
        $out .= ",$r->{name}";
    }
    return $out;
}

sub _showSubnetApi {

    my ($session, $params, $theTopic, $theWeb) = @_;

    my $cfg;
    foreach my $row (@{ $Foswiki::cfg{Plugins}{EyeShowPlugin}{Configs} }) {
        next if ($row->{web} ne $theWeb);
        $cfg = $row;
        last;
    }

    return "EyeShowPlugin: no config for web '$theWeb'" unless $cfg;

    my $subnet = $params->{Subnet} || '';
    return "Error: Subnet required" unless $subnet;

    my $filter = encode_json({ subnet => $subnet });
    my $data = _getApiData($cfg, "get=table_record&table=subnets&filter=".uri_escape($filter));
    return "No data for subnet $subnet" unless $data;

    my $out = join("<br>",
        "Первый адрес: ". IpToStr($data->{ip_int_start}+1),
        "Последний адрес: ". IpToStr($data->{ip_int_stop}-1),
        "Начало dhcp пула: ". IpToStr($data->{dhcp_start}),
        "Конец dhcp пула: ". IpToStr($data->{dhcp_stop}),
        "Шлюз: ". IpToStr($data->{gateway}),
        "Время аренды: ". $data->{dhcp_lease_time}. " min",
    );

    return $out;
}

sub _showUserListApi {
    my ($session, $params, $theTopic, $theWeb) = @_;

    my $cfg;
    foreach my $row (@{ $Foswiki::cfg{Plugins}{EyeShowPlugin}{Configs} }) {
        next if ($row->{web} ne $theWeb);
        $cfg = $row;
        last;
    }

    return "EyeShowPlugin: no config for web '$theWeb'" unless $cfg;

    my $subnet = $params->{Subnet} || '';
    return "Error: Subnet required" unless $subnet;

    my $data = _getApiData($cfg, "get=user_subnet&subnet=".uri_escape($subnet));
    return "No data for subnet $subnet" unless $data;

    my $out = "| *IP* | *MAC* | *Desciption* | *DNS* | *DHCP Name* |\n";

    foreach my $r (@{ $data }) {
        $out .= "| $r->{ip} | $r->{mac} | $r->{description} | $r->{dns_name} | $r->{dhcp_hostname} |\n";
    }

    return $out;
}

1;
